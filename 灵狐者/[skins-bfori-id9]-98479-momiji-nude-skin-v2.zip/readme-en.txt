Momiji Nude Skin v2

################################################################################################

AUTHORS
------------------------------------------------------------------------------------------------
modeeper Main author

################################################################################################


------------------------------------------------------------------------------------------------
Import files in the IMG archive
You can download IMG Manager 2.0 here: https://www.gtaall.com/gta-san-andreas/programs/37425-img-manager-20.html
Crazy IMG Editor here : https://www.gtaall.com/gta-san-andreas/programs/3884-gta-sa-crazy-img-editor.html

Use IMG Manager 2.0 or Crazy IMG Editor to import files from the folder "00 - Import to gta3.img" to archive [GAME FOLDER]\models\gta3.img:
bfori.dff
bfori.txd

################################################################################################

This modification has been downloaded from www.gtaall.com
Permanent link to modification`s page: https://www.gtaall.com/gta-san-andreas/skins/98479-momiji-nude-skin-v2.html