Momiji Nude Skin v2

################################################################################################

AUTEURS
------------------------------------------------------------------------------------------------
modeeper L'auteur principal

################################################################################################


------------------------------------------------------------------------------------------------
Importer des fichiers dans l'archive IMG
Vous pouvez telecharger IMG Manager 2.0 ici: https://www.gtaall.eu/fr/gta-san-andreas/programs/37425-img-manager-20.html
Crazy IMG Editor ici: https://www.gtaall.eu/fr/gta-san-andreas/programs/3884-gta-sa-crazy-img-editor.html

Utilisez IMG Manager 2.0 ou Crazy IMG Editor d'importer des fichiers a partir du dossier "00 - Import to gta3.img" pour archiver [JEU DOSSIER]\models\gta3.img:
bfori.dff
bfori.txd

################################################################################################

Cette modification a ete telecharge a partir de www.gtaall.eu
Permanent lien vers modification`s page: https://www.gtaall.eu/gta-san-andreas/skins/98479-momiji-nude-skin-v2.html