Momiji Nude Skin v2

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
modeeper Autor principal

################################################################################################


------------------------------------------------------------------------------------------------
Importar arquivos no arquivo IMG
Voce pode baixar IMG Manager 2.0 aqui: https://www.gtaall.com.br/gta-san-andreas/programs/37425-img-manager-20.html
Crazy IMG editor aqui: https://www.gtaall.com.br/gta-san-andreas/programs/3884-gta-sa-crazy-img-editor.html

Use IMG Manager 2.0 ou Crazy IMG Editor para importar os arquivos da pasta "00 - Import to gta3.img" para arquivar [GAME PASTA]\models\gta3.img:
bfori.dff
bfori.txd

################################################################################################

Esta modificacao foi baixado www.gtaall.com.br
Permanent link para modification`s pagina: https://www.gtaall.com.br/gta-san-andreas/skins/98479-momiji-nude-skin-v2.html