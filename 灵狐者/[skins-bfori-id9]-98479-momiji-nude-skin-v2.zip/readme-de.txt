Momiji Nude Skin v2

################################################################################################

AUTOREN
------------------------------------------------------------------------------------------------
modeeper Hauptautor

################################################################################################


------------------------------------------------------------------------------------------------
Importieren von Dateien in der IMG-Archiv
Sie konnen IMG Manager 2.0 hier herunterladen: https://www.gtaall.eu/de/gta-san-andreas/programs/37425-img-manager-20.html
Crazy IMG Editor hier: https://www.gtaall.eu/de/gta-san-andreas/programs/3884-gta-sa-crazy-img-editor.html

Verwenden IMG Manager 2.0 oder Crazy IMG Editor, um Dateien aus dem Ordner "00 - Import to gta3.img" zu importieren, um zu archivieren [GAME FOLDER]\models\gta3.img:
bfori.dff
bfori.txd

################################################################################################

Diese Modifikation wurde von www.gtaall.eu heruntergeladen wurden
Permanent Link zu Seite modification`s: https://www.gtaall.eu/gta-san-andreas/skins/98479-momiji-nude-skin-v2.html