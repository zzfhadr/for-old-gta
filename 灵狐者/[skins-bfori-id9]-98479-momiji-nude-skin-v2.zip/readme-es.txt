Momiji Nude Skin v2

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
modeeper Autor principal

################################################################################################


------------------------------------------------------------------------------------------------
Importacion de archivos en el archivo IMG
No puede descargar IMG Manager 2.0 aqui: https://www.gtaall.net/gta-san-andreas/programs/37425-img-manager-20.html
Crazy IMG Editor aqui: https://www.gtaall.net/gta-san-andreas/programs/3884-gta-sa-crazy-img-editor.html

Utilice IMG Manager 2.0 o Crazy IMG Editor para importar archivos desde la carpeta "00 - Import to gta3.img" para archivar [JUEGO CARPETA]\models\gta3.img:
bfori.dff
bfori.txd

################################################################################################

Esta modificacion ha sido descargado de www.gtaall.net
Permanent enlace a modification`s pagina: https://www.gtaall.net/gta-san-andreas/skins/98479-momiji-nude-skin-v2.html