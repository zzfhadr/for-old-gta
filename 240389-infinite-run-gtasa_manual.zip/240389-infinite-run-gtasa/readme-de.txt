Infinite Run
-------------------------------------------------------------
Данный мод позволяет вам бесконечно бегать.
Эту опцию можно как включить, так и выключить (подробнее в файле Run.ini)
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Seite des Autors: www.youtube.com/channel/UCNW2Mn-7-DVGDbk-vHwY9yA?view_as=subscriber
Email des Autors: danya.zagoruyko.98@mail.ru
Der Autor: CHRISREDFIELD
Auf der Site vom Benutzer hinzugefuegt wurde: CHRISREDFIELD
-------------------------------------------------------------
2) Kopieren von Dateien:
Alle Inhalte des Ordners "To copy to game folder" Kopieren Sie in den Spiel-Ordner den Ersatz bestaetigt.

(!) Wenn Sie in der Lage sein, die Aenderung zu entfernen, stellen Sie sicher, dass Sie die Original-Kopien ersetzten Dateien an einem sicheren Ort erhalten.
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
