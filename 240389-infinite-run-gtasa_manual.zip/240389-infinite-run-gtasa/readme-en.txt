Infinite Run
-------------------------------------------------------------
Данный мод позволяет вам бесконечно бегать.
Эту опцию можно как включить, так и выключить (подробнее в файле Run.ini)
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author`s site: www.youtube.com/channel/UCNW2Mn-7-DVGDbk-vHwY9yA?view_as=subscriber
Author`s Email: danya.zagoruyko.98@mail.ru
Author: CHRISREDFIELD
Was added to the site by user: CHRISREDFIELD
-------------------------------------------------------------
2) Copying files:
All contents of the folder "To copy to game folder" copy into the game folder confirming the replacement.

(!) If You wish to be able to remove a modification, make sure You save original copies of the replaced files safely.
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
